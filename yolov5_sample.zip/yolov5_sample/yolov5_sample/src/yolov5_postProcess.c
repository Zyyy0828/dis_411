#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

#include "Tensor.h"
#include "yolov5_postProcess.h"


float sigmoid(float x){
	return (1.0f / ((float)exp((double)(-x)) + 1.0f));
}

void yolov5_result_process(Tensor *arrFeature, float *strides, anchor_w_h (*anchor_grids)[3], int imgW, int imgH, float prob_threshold, YOLOV5_RESULT **output_result)
{
    YOLOV5_RESULT *current = NULL;
	
	YOLOV5_RESULT *former = NULL;
	
	*output_result = NULL;

    // unsigned int resltu_num = 0;
    // for (int yolo_layer_index = 0; yolo_layer_index < sizeof(arrFeature)/sizeof(arrFeature[0]); yolo_layer_index ++)
    for (int yolo_layer_index = 0; yolo_layer_index < 3 ; yolo_layer_index ++)
    {

        Tensor feature = arrFeature[yolo_layer_index];

        int anchor_nums = feature.channel;
        int map_w = sqrt(feature.width);

        for(int anchor_index = 0; anchor_index < anchor_nums; ++anchor_index)  //每个 grid 上有三个 anchor
        {
            int anchor_stride = anchor_index * feature.width * feature.height;
            float anchor_w = anchor_grids[yolo_layer_index][anchor_index].anchor_w;
            float anchor_h = anchor_grids[yolo_layer_index][anchor_index].anchor_h;

            for(int num_grid = 0; num_grid < feature.width; ++num_grid)   // feature size 拉直后的长度，如 1600 400 100.
            {
                int y = num_grid / map_w;
                int x = num_grid % map_w;

                float confidence = feature.data[anchor_stride + 4 * feature.width + num_grid];
                confidence = sigmoid(confidence);
                
                if(confidence > prob_threshold)
                {
                    for(int class_index = 5; class_index < feature.height; ++class_index)
                    {
                        float class_confidence = feature.data[anchor_stride + class_index * feature.width + num_grid];
                        class_confidence = sigmoid(class_confidence) * confidence;
                        
                        if(class_confidence > prob_threshold)
                        {
                            //printf("confidence %f\n", class_confidence);
                            float dx = feature.data[anchor_stride + 0 * feature.width + num_grid];
                            float dy = feature.data[anchor_stride + 1 * feature.width + num_grid];
                            float dw = feature.data[anchor_stride + 2 * feature.width + num_grid];
                            float dh = feature.data[anchor_stride + 3 * feature.width + num_grid];

                            dx = sigmoid(dx);
                            dy = sigmoid(dy);
                            dw = sigmoid(dw);
                            dh = sigmoid(dh);

                            dx = (dx * 2.0f - 0.5f + (float)x) * strides[yolo_layer_index];
                            dy = (dy * 2.0f - 0.5f + (float)y) * strides[yolo_layer_index];
                            dw = (dw * 2.0f) * (dw * 2.0f) * anchor_w;
                            dh = (dh * 2.0f) * (dh * 2.0f) * anchor_h;

                            // 坐标转换 (x y w h) -> (x y x y)
                            float x0 = YOLO_MAX((dx - (dw - 1.0f) * 0.5f), 0.0f);
                            float y0 = YOLO_MAX((dy - (dh - 1.0f) * 0.5f), 0.0f);
                            float x1 = YOLO_MIN((dx + (dw - 1.0f) * 0.5f), imgW); 
                            float y1 = YOLO_MIN((dy + (dh - 1.0f) * 0.5f), imgH);

                            // float x0 = dx - (dw - 1.0f) * 0.5f;
                            // float x1 = dx + (dw - 1.0f) * 0.5f;
                            // float y0 = dy - (dh - 1.0f) * 0.5f;
                            // float y1 = dy + (dh - 1.0f) * 0.5f;


                            current = (YOLOV5_RESULT *) malloc(sizeof(YOLOV5_RESULT));
                            current->x = x0;
                            current->y = y0;
                            current->width = x1 - x0;
                            current->height = y1 -y0;
                            current->class_label =  class_index - 5;
                            current->confidence = class_confidence;
                            current->next = NULL;

                            if (*output_result == NULL) // 存储结果
                            { 
                                *output_result = current;
                                former = current;
                            
                            }else{
                                former->next = current;
                                former = former->next;
                            }
                            current = NULL;
                        }
                    }
                }

            }
        }
    }
    // return resltu_num;
}


void yolov5_result_sort(YOLOV5_RESULT *output_result)// 目前用这个做排序
{ 
	
	YOLOV5_RESULT *comparable_node = NULL; // 右节点，挨个指向右边所有节点
	
	YOLOV5_RESULT *comparable_next_node = NULL;
	
	YOLOV5_RESULT *current_node = output_result; // 左节点，其与右边每个节点做比较

	YOLOV5_RESULT *current_next_node = NULL;
	
	YOLOV5_RESULT temp_node = {0};

    if(current_node == NULL)
    {
        return;
    }
        
	
	while (current_node != NULL)
    {
		comparable_node = current_node->next;
	
		current_next_node = current_node->next; // 记录后续节点，方便调换数据后维持链表完整
	
		while (comparable_node != NULL)
        {
			
			comparable_next_node = comparable_node->next; // 记录后续节点，方便调换数据后维持链表完整
			
			if (current_node->confidence >= comparable_node->confidence)
            { // 如果大于它，说明后面的比它小，比较下一个
				
				comparable_node = comparable_node->next;
				
			}
            else
            {
				// 当大于 current_confidence 时，数据做调换，内存不变，小的放后面去
				memcpy(&temp_node, current_node, sizeof(YOLOV5_RESULT));
				
				memcpy(current_node, comparable_node, sizeof(YOLOV5_RESULT));
				
				memcpy(comparable_node, &temp_node, sizeof(YOLOV5_RESULT));
				
				current_node->next = current_next_node; // 链表接好
				
				comparable_node->next = comparable_next_node;

				comparable_node = comparable_node->next; //更新位置，因为当前节点已经小于current_node ，不必再做比较
			}
			
		}
		current_node = current_node->next;
	}
}


static float intersection_area(YOLOV5_RESULT *current_node ,YOLOV5_RESULT *comparable_node)
{
    float axmin = current_node->x;
    float axmax = current_node->x + current_node->width;
    float aymin = current_node->y;
    float aymax = current_node->y + current_node->height;
    float bxmin = comparable_node->x;
    float bxmax = comparable_node->x + comparable_node->width;
    float bymin = comparable_node->y;
    float bymax = comparable_node->y + comparable_node->height;

    if(axmin > bxmax || axmax < bxmin || aymin > bymax || aymax < bymin)
    {
        return 0.f; // no intersection
    }

    // cv::Rect_<float> inter = a.bbox & b.bbox;
    // return inter.area();
    // float inter_width = std::min(axmax, bxmax) - std::max(axmin, bxmin);
    // float inter_height = std::min(aymax, bymax) - std::max(aymin, bymin);

    float inter_width = YOLO_MIN(axmax, bxmax) - YOLO_MAX(axmin, bxmin);
    float inter_height = YOLO_MIN(aymax, bymax) - YOLO_MAX(aymin, bymin);
    return inter_height * inter_width;
}


void yolov5_nms(YOLOV5_RESULT *output_result, float iou_threshold)
{ 

	YOLOV5_RESULT *comparable_node = NULL; // 右节点，挨个指向右边所有节点
	
	YOLOV5_RESULT *comparable_former_node = NULL;
	
	YOLOV5_RESULT *current_node = output_result; // 左节点，其与右边每个节点做比较

	YOLOV5_RESULT *temp_node = NULL;

	// float overlap_left_x = 0.0f;

	// float overlap_left_y = 0.0f;

	// float overlap_right_x = 0.0f;

	// float overlap_right_y = 0.0f;

	float current_area = 0.0f, comparable_area = 0.0f, overlap_area = 0.0f;

	float nms_ratio = 0.0f;

	// float overlap_w = 0.0f, overlap_h = 0.0f;
	
	// yolo v5 的 nms 实现很优雅，我没在这里用
	while (current_node != NULL){
	
		comparable_node = current_node->next;

		comparable_former_node = current_node;
		//printf("current_node->score = %f\n", current_node->score);
		// current_area = (current_node->right_down_x - current_node->left_up_x) * (current_node->right_down_y - current_node->left_up_y);
        current_area = current_node->width * current_node->height;
	
		while (comparable_node != NULL){
			
			if (current_node->class_label != comparable_node->class_label){ // 如果类别不一致，没必要做 nms
			
				comparable_former_node = comparable_node;

				comparable_node = comparable_node->next;
				continue;
			}
			//printf("comparable_node->score = %f\n", comparable_node->score);
			// comparable_area = (comparable_node->right_down_x - comparable_node->left_up_x) * (comparable_node->right_down_y - comparable_node->left_up_y);
            comparable_area = comparable_node->width * comparable_node->height;

            overlap_area = intersection_area(current_node ,comparable_node);

			// overlap_left_x = YOLO_MAX(current_node->left_up_x, comparable_node->left_up_x);
			// overlap_left_y = YOLO_MAX(current_node->left_up_y, comparable_node->left_up_y);

			// overlap_right_x = YOLO_MIN(current_node->right_down_x, comparable_node->right_down_x);
			// overlap_right_y = YOLO_MIN(current_node->right_down_y, comparable_node->right_down_y);

			// overlap_w = YOLO_MAX((overlap_right_x - overlap_left_x), 0.0F);
			// overlap_h = YOLO_MAX((overlap_right_y - overlap_left_y), 0.0F);
			// overlap_area = YOLO_MAX((overlap_w * overlap_h), 0.0f); // 重叠区域面积

			nms_ratio = overlap_area / (current_area + comparable_area - overlap_area);
			
			if (nms_ratio > iou_threshold){ // 重叠过大，去掉
			
				temp_node = comparable_node;
				
				comparable_node = comparable_node->next;

				comparable_former_node->next = comparable_node; // 链表接好
				
				free(temp_node);
			}else{
				
				comparable_former_node = comparable_node;
				
				comparable_node = comparable_node->next;
			}
			
		}
		//printf("loop end \n");
		current_node = current_node->next;
	}
}


void yolov5_printf_result(YOLOV5_RESULT *temp)
{
	printf("--------------------\n");

	while (temp != NULL){
		
		printf("output_result->x = %f\t", temp->x);
		printf("output_result->y = %f\n", temp->y);

		printf("output_result->w = %f\t", temp->width);
		printf("output_result->h = %f\n", temp->height);

		printf("output_result->class_index = %d\t", temp->class_label);
		printf("output_result->score = %f\n\n", temp->confidence);
		
		temp = temp->next;
	}
	printf("--------------------\n");
}


void yolov5_release_result(YOLOV5_RESULT *output_result)
{

	YOLOV5_RESULT *temp = NULL;

	while (output_result != NULL){
		
		temp = output_result;
		
		output_result = output_result->next;
	
		free(temp);
	}
}



