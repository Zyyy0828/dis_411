#include "nnie_core.h"





/******************************************************************************
* function : NNIE Param Deinit
******************************************************************************/
static int NNIE_Param_Deinit(SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam, SAMPLE_SVP_NNIE_MODEL_S *pstNnieModel)
{
    HI_S32 s32Ret = HI_SUCCESS;
    /*hardware para deinit*/
    if (pstNnieParam != NULL)
    {
        s32Ret = SAMPLE_COMM_SVP_NNIE_ParamDeinit(pstNnieParam);
        SAMPLE_SVP_CHECK_EXPR_TRACE(HI_SUCCESS != s32Ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
                                    "Error,SAMPLE_COMM_SVP_NNIE_ParamDeinit failed!\n");
    }
    /*model deinit*/
    if (pstNnieModel != NULL)
    {
        s32Ret = SAMPLE_COMM_SVP_NNIE_UnloadModel(pstNnieModel);
        SAMPLE_SVP_CHECK_EXPR_TRACE(HI_SUCCESS != s32Ret, SAMPLE_SVP_ERR_LEVEL_ERROR,
                                    "Error,SAMPLE_COMM_SVP_NNIE_UnloadModel failed!\n");
    }
    return s32Ret;
}



/******************************************************************************
* function : NNIE Forward
******************************************************************************/
static HI_S32 NNIE_Forward(SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam,
    SAMPLE_SVP_NNIE_INPUT_DATA_INDEX_S* pstInputDataIdx,
    SAMPLE_SVP_NNIE_PROCESS_SEG_INDEX_S* pstProcSegIdx,HI_BOOL bInstant)
{
    HI_S32 s32Ret = HI_SUCCESS;
    HI_U32 i = 0, j = 0;
    HI_BOOL bFinish = HI_FALSE;
    SVP_NNIE_HANDLE hSvpNnieHandle = 0;
    HI_U32 u32TotalStepNum = 0;
    // SAMPLE_SVP_NIE_PERF_STAT_DEF_VAR()

    // SAMPLE_SVP_NNIE_PERF_STAT_OP_FORWARD_CLREAR()

    SAMPLE_COMM_SVP_FlushCache(pstNnieParam->astForwardCtrl[pstProcSegIdx->u32SegIdx].stTskBuf.u64PhyAddr,
        SAMPLE_SVP_NNIE_CONVERT_64BIT_ADDR(HI_VOID,pstNnieParam->astForwardCtrl[pstProcSegIdx->u32SegIdx].stTskBuf.u64VirAddr),
        pstNnieParam->astForwardCtrl[pstProcSegIdx->u32SegIdx].stTskBuf.u32Size);

    // SAMPLE_SVP_NNIE_PERF_STAT_BEGIN()
    for(i = 0; i < pstNnieParam->astForwardCtrl[pstProcSegIdx->u32SegIdx].u32DstNum; i++)
    {
        if(SVP_BLOB_TYPE_SEQ_S32 == pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].enType)
        {
            for(j = 0; j < pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u32Num; j++)
            {
                u32TotalStepNum += *(SAMPLE_SVP_NNIE_CONVERT_64BIT_ADDR(HI_U32,pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].unShape.stSeq.u64VirAddrStep)+j);
            }
            SAMPLE_COMM_SVP_FlushCache(pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u64PhyAddr,
                SAMPLE_SVP_NNIE_CONVERT_64BIT_ADDR(HI_VOID,pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u64VirAddr),
                u32TotalStepNum*pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u32Stride);

        }
        else
        {
            SAMPLE_COMM_SVP_FlushCache(pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u64PhyAddr,
                SAMPLE_SVP_NNIE_CONVERT_64BIT_ADDR(HI_VOID,pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u64VirAddr),
                pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u32Num*
                pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].unShape.stWhc.u32Chn*
                pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].unShape.stWhc.u32Height*
                pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u32Stride);
        }
    }
    // SAMPLE_SVP_NNIE_PERF_STAT_END()
    // SAMPLE_SVP_NNIE_PERF_STAT_OP_FORWARD_PRE_DST_FLUSH_TIME()

    /*set input blob according to node name*/
    if(pstInputDataIdx->u32SegIdx != pstProcSegIdx->u32SegIdx)
    {
        for(i = 0; i < pstNnieParam->pstModel->astSeg[pstProcSegIdx->u32SegIdx].u16SrcNum; i++)
        {
            for(j = 0; j < pstNnieParam->pstModel->astSeg[pstInputDataIdx->u32SegIdx].u16DstNum; j++)
            {
                if(0 == strncmp(pstNnieParam->pstModel->astSeg[pstInputDataIdx->u32SegIdx].astDstNode[j].szName,
                    pstNnieParam->pstModel->astSeg[pstProcSegIdx->u32SegIdx].astSrcNode[i].szName,
                    SVP_NNIE_NODE_NAME_LEN))
                {
                    pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astSrc[i] =
                        pstNnieParam->astSegData[pstInputDataIdx->u32SegIdx].astDst[j];
                    break;
                }
            }
            SAMPLE_SVP_CHECK_EXPR_RET((j == pstNnieParam->pstModel->astSeg[pstInputDataIdx->u32SegIdx].u16DstNum),
                HI_FAILURE,SAMPLE_SVP_ERR_LEVEL_ERROR,"Error,can't find %d-th seg's %d-th src blob!\n",
                pstProcSegIdx->u32SegIdx,i);
        }
    }

    /*NNIE_Forward*/
    // SAMPLE_SVP_NNIE_PERF_STAT_BEGIN()
    s32Ret = HI_MPI_SVP_NNIE_Forward(&hSvpNnieHandle,
        pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astSrc,
        pstNnieParam->pstModel, pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst, //astDst 包含 最终结果输出 以及 中间层输出（需要设置上报） 。
        &pstNnieParam->astForwardCtrl[pstProcSegIdx->u32SegIdx], bInstant);
    SAMPLE_SVP_CHECK_EXPR_RET(HI_SUCCESS != s32Ret,s32Ret,SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,HI_MPI_SVP_NNIE_Forward failed!\n");

    if(bInstant) // 该值为 HI_MPI_SVP_NNIE_Forward 输出结果标志 。
    {
        /*Wait NNIE finish*/
        while(HI_ERR_SVP_NNIE_QUERY_TIMEOUT == (s32Ret = HI_MPI_SVP_NNIE_Query(pstNnieParam->astForwardCtrl[pstProcSegIdx->u32SegIdx].enNnieId,
            hSvpNnieHandle, &bFinish, HI_TRUE)))
        {
            usleep(100);
            SAMPLE_SVP_TRACE(SAMPLE_SVP_ERR_LEVEL_INFO,
                "HI_MPI_SVP_NNIE_Query Query timeout!\n");
        }
    }
    // SAMPLE_SVP_NNIE_PERF_STAT_END()
    // SAMPLE_SVP_NNIE_PERF_STAT_OP_FORWARD_OP_TIME()
    u32TotalStepNum = 0;

    // SAMPLE_SVP_NNIE_PERF_STAT_BEGIN()
    for(i = 0; i < pstNnieParam->astForwardCtrl[pstProcSegIdx->u32SegIdx].u32DstNum; i++)
    {
        if(SVP_BLOB_TYPE_SEQ_S32 == pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].enType)
        {
            for(j = 0; j < pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u32Num; j++)
            {
                u32TotalStepNum += *(SAMPLE_SVP_NNIE_CONVERT_64BIT_ADDR(HI_U32,pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].unShape.stSeq.u64VirAddrStep)+j);
            }
            //刷新 cache 里的内容到内存并且使 cache 里的内容无效。
            SAMPLE_COMM_SVP_FlushCache(pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u64PhyAddr,
                SAMPLE_SVP_NNIE_CONVERT_64BIT_ADDR(HI_VOID,pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u64VirAddr),
                u32TotalStepNum*pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u32Stride);

        }
        else
        {
            SAMPLE_COMM_SVP_FlushCache(pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u64PhyAddr,
                SAMPLE_SVP_NNIE_CONVERT_64BIT_ADDR(HI_VOID,pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u64VirAddr),
                pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u32Num*
                pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].unShape.stWhc.u32Chn*
                pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].unShape.stWhc.u32Height*
                pstNnieParam->astSegData[pstProcSegIdx->u32SegIdx].astDst[i].u32Stride);
        }
    }
    // SAMPLE_SVP_NNIE_PERF_STAT_END()
    // SAMPLE_SVP_NNIE_PERF_STAT_OP_FORWARD_AFTER_DST_FLUSH_TIME()

    return s32Ret;
}


/******************************************************************************
* function : NNIE Get Tensor Result
******************************************************************************/
static HI_S32 NNIE_Get_Result(SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam, Tensor *output_tensors)
{
    HI_U32 u32SegNum = pstNnieParam->pstModel->u32NetSegNum;
    HI_U32 i = 0, j = 0, k = 0, n = 0;
    HI_U32 u32SegIdx = 0, u32NodeIdx = 0;
    HI_U32 *pu32StepAddr = NULL;
    HI_S32 *ps32ResultAddr = NULL;
    HI_U32 u32Height = 0, u32Width = 0, u32Chn = 0, u32Stride = 0, u32Dim = 0;

    for (u32SegIdx = 0; u32SegIdx < u32SegNum; u32SegIdx++)
    {
        for (u32NodeIdx = 0; u32NodeIdx < pstNnieParam->pstModel->astSeg[u32SegIdx].u16DstNum; u32NodeIdx++)
        {

            Tensor t;
            if (SVP_BLOB_TYPE_SEQ_S32 == pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].enType)
            {
                u32Dim = pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].unShape.stSeq.u32Dim;
                u32Stride = pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].u32Stride;
                pu32StepAddr = (HI_U32 *)(pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].unShape.stSeq.u64VirAddrStep);
                ps32ResultAddr = (HI_S32 *)(pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].u64VirAddr);
                for (n = 0; n < pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].u32Num; n++)
                {
                    for (i = 0; i < *(pu32StepAddr + n); i++)
                    {
                        for (j = 0; j < u32Dim; j++)
                        {
                        }
                        ps32ResultAddr += u32Stride / sizeof(HI_U32);
                    }
                }
            }
            else
            {
                u32Height = pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].unShape.stWhc.u32Height;
                u32Width = pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].unShape.stWhc.u32Width;
                u32Chn = pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].unShape.stWhc.u32Chn;
                u32Stride = pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].u32Stride;
                ps32ResultAddr = (HI_S32 *)(pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].u64VirAddr);
                t.n = pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].u32Num;
                t.channel = u32Chn;
                t.height = u32Height;
                t.width = u32Width;
                t.data = (float *)ps32ResultAddr;
                float *tmp = t.data;

                for (n = 0; n < pstNnieParam->astSegData[u32SegIdx].astDst[u32NodeIdx].u32Num; n++)
                {
                    for (i = 0; i < u32Chn; i++)
                    {
                        for (j = 0; j < u32Height; j++)
                        {
                            for (k = 0; k < u32Width; k++)
                            {
                                *(tmp + k) = (*(ps32ResultAddr + k)) * 1.0f / SAMPLE_SVP_NNIE_QUANT_BASE;
                            }
                            ps32ResultAddr += u32Stride / sizeof(HI_U32);
                            tmp += t.width;
                        }
                    }
                }
                output_tensors[u32NodeIdx] = t;
            }
        }
    }
    return HI_SUCCESS;
}


/******************************************************************************
* function : nnie load model
******************************************************************************/
int _nnie_load_model(const char *model_path, SAMPLE_SVP_NNIE_MODEL_S *s_stModel)
{
    /*NNIE Load Model*/
    // SAMPLE_COMM_SVP_CheckSysInit();
    char *_model_path = (char *)model_path;
    printf("========== NNIE Load Model ==========\n");
    HI_S32 s32Ret = SAMPLE_COMM_SVP_NNIE_LoadModel(_model_path, s_stModel);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_SVP_TRACE_INFO("Error,SAMPLE_COMM_SVP_NNIE_LoadModel failed!\n");
        return -1;
    }
    return 0;
}


/******************************************************************************
* function : nnie parameter initialization
******************************************************************************/
int nnie_param_init(SAMPLE_SVP_NNIE_MODEL_S *pstModel, SAMPLE_SVP_NNIE_CFG_S *pstCfg,
                     SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam)
{
    HI_S32 s32Ret = HI_SUCCESS;

    /*nnie param init*/
    pstCfg->pszPic= NULL;
    pstCfg->u32MaxInputNum = 1; //max input image num in each batch
    pstCfg->u32MaxRoiNum = 0;
    pstCfg->aenNnieCoreId[0] = SVP_NNIE_ID_0;//set NNIE core
    pstNnieParam->pstModel = &pstModel->stModel;


    //初始化软硬件参数，硬件参数基本不变
    /*NNIE Parameter Initialization*/
    s32Ret = SAMPLE_COMM_SVP_NNIE_ParamInit(pstCfg, pstNnieParam);
    SAMPLE_SVP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret,NNIE_FAIL_0,SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error,SAMPLE_COMM_SVP_NNIE_ParamInit failed!\n");
    printf("========== NNIE Parameter Init End! ==========\n");

    // 记录 TskBuf 地址信息 ,用于减少内核态内存映射次数 ,提升效率 。
    /*record tskBuf*/  
    // s32Ret = HI_MPI_SVP_NNIE_AddTskBuf(&(pstNnieParam->astForwardCtrl[0].stTskBuf)); 
    // SAMPLE_SVP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret,NNIE_FAIL_0, SAMPLE_SVP_ERR_LEVEL_ERROR,
    //     "Error,HI_MPI_SVP_NNIE_AddTskBuf failed!\n");
    // printf("========== NNIE AddTskBuf end! ==========\n");

    return s32Ret;

    NNIE_FAIL_0:
        NNIE_Param_Deinit(pstNnieParam, pstModel);
        // SAMPLE_COMM_SVP_CheckSysExit();
        return s32Ret;
}


/******************************************************************************
* function : nnie inference(YVU420SP)-VIDEO_FRAME_INFO_S
******************************************************************************/
int nnie_inference(SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam, VIDEO_FRAME_INFO_S *pstExtFrmInfo, Tensor *output_tensors)
{
    /*****************获取推理图像大小***********************/
    // HI_U32 u32BaseWidth = 0;
    // HI_U32 u32BaseHeight = 0;
    // u32BaseWidth = pstExtFrmInfo->stVFrame.u32Width;
    // u32BaseHeight = pstExtFrmInfo->stVFrame.u32Height;
    // printf("###u32W:%d\n",u32BaseWidth);
    // printf("###u32H:%d\n",u32BaseHeight);
    /*****************************************************/

    HI_S32 s32Ret = HI_SUCCESS;

    SAMPLE_SVP_NNIE_INPUT_DATA_INDEX_S stInputDataIdx = {0};   //数据填充网络索引
    SAMPLE_SVP_NNIE_PROCESS_SEG_INDEX_S stProcSegIdx = {0};    //推理过程中因为不支持层索引

    //(1)Fill SRC data
    //初始输入图片的节点，０段的第０层
    stInputDataIdx.u32SegIdx = 0;   //段索引
    stInputDataIdx.u32NodeIdx = 0;  //层节点索引
    /*SP420*/
    //储存在pstExtFrmInfo里的vpss图片帧，放入硬件配置的输入地址里
    pstNnieParam->astSegData[stInputDataIdx.u32SegIdx].astSrc[stInputDataIdx.u32NodeIdx].u64VirAddr = pstExtFrmInfo->stVFrame.u64VirAddr[0];
    pstNnieParam->astSegData[stInputDataIdx.u32SegIdx].astSrc[stInputDataIdx.u32NodeIdx].u64PhyAddr = pstExtFrmInfo->stVFrame.u64PhyAddr[0];
    pstNnieParam->astSegData[stInputDataIdx.u32SegIdx].astSrc[stInputDataIdx.u32NodeIdx].u32Stride  = pstExtFrmInfo->stVFrame.u32Stride[0];

   

    /*(2)NNIE process(process the 0-th segment)*/
    stProcSegIdx.u32SegIdx = 0;
    s32Ret = NNIE_Forward(pstNnieParam,&stInputDataIdx,&stProcSegIdx,HI_TRUE);
    if(HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("Error(%#x),Error,SAMPLE_SVP_NNIE_Forward failed!\n", s32Ret);
        return s32Ret;
    }

   
    
    /*(3)Post process*///获取不支持层
    s32Ret = NNIE_Get_Result(pstNnieParam, output_tensors);
    if(HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("Error(%#x),Error,NNIE_Get_Result failed!\n", s32Ret);
        return s32Ret;
    }
 
    return s32Ret;
}








/******************************************************************************
* function : nnie param deinit
******************************************************************************/
int nnie_param_deinit(SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam, SAMPLE_SVP_NNIE_MODEL_S *pstNnieModel)
{
    HI_S32 s32Ret = HI_SUCCESS;

    // s32Ret = HI_MPI_SVP_NNIE_RemoveTskBuf(&(pstNnieParam->astForwardCtrl[0].stTskBuf));
    // SAMPLE_SVP_CHECK_EXPR_RET(HI_SUCCESS != s32Ret,s32Ret,SAMPLE_SVP_ERR_LEVEL_ERROR,
    //     "Error(%#x),HI_MPI_SVP_NNIE_RemoveTskBuf failed!\n",s32Ret);


    s32Ret = NNIE_Param_Deinit(pstNnieParam, pstNnieModel);
    SAMPLE_SVP_CHECK_EXPR_RET(HI_SUCCESS != s32Ret,s32Ret,SAMPLE_SVP_ERR_LEVEL_ERROR,
        "Error(%#x),SAMPLE_SVP_NNIE_Deinit failed!\n",s32Ret);

    
    return s32Ret;
}