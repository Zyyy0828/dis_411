
#include<math.h>

#include "utils.h"
#include "hi_comm_sys.h"
#include "mpi_sys.h"
#include "mpi_vgs.h"

#define MY_SVP_MAX(a, b) (((a) > (b)) ? (a) : (b))
#define MY_SVP_MIN(a, b) (((a) < (b)) ? (a) : (b))


void RECT_TO_POINT(MY_RECT_ARRAY_S *pstRect_u, MY_POINT_ARRAY_S *pstPoint_u)
{
    int i;
    for(i = 0; i < pstRect_u->u16Num; i++)
    {
        pstPoint_u->astPoint[i].astPoint_u[0].uX = pstRect_u->astRect[i].stRect_u.uX;
        pstPoint_u->astPoint[i].astPoint_u[0].uY = pstRect_u->astRect[i].stRect_u.uY;
        pstPoint_u->astPoint[i].astPoint_u[1].uX = pstRect_u->astRect[i].stRect_u.uX + pstRect_u->astRect[i].stRect_u.uWidth;
        pstPoint_u->astPoint[i].astPoint_u[1].uY = pstRect_u->astRect[i].stRect_u.uY;
        pstPoint_u->astPoint[i].astPoint_u[2].uX = pstRect_u->astRect[i].stRect_u.uX + pstRect_u->astRect[i].stRect_u.uWidth;
        pstPoint_u->astPoint[i].astPoint_u[2].uY = pstRect_u->astRect[i].stRect_u.uY + pstRect_u->astRect[i].stRect_u.uHeight; 
        pstPoint_u->astPoint[i].astPoint_u[3].uX = pstRect_u->astRect[i].stRect_u.uX;
        pstPoint_u->astPoint[i].astPoint_u[3].uY = pstRect_u->astRect[i].stRect_u.uY + pstRect_u->astRect[i].stRect_u.uHeight;

        #if 0
        int j;
        for( j = 0; j < 4; j++)
        {
            printf("###NUM %d:  X%d = %d   Y%d = %d\n",i, j, pstPoint_u->astPoint[i].astPoint_u[j].uX, j, pstPoint_u->astPoint[i].astPoint_u[j].uY);
        }
        #endif
    }
    return;
}


HI_S32 MY_Fill_ONE_Rect(VIDEO_FRAME_INFO_S *pstFrmInfo, MY_POINT_ARRAY_S* pstbbox, HI_U32 u32Color)
{
    VGS_HANDLE VgsHandle = -1;
    HI_S32 s32Ret = HI_SUCCESS;
    // HI_U32 i,j;
    VGS_TASK_ATTR_S stVgsTask;
    VGS_ADD_COVER_S stVgsAddCover;
    static HI_U32 u32Frm = 0;
    u32Frm++;
    
    s32Ret = HI_MPI_VGS_BeginJob(&VgsHandle);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Vgs begin job fail,Error(%#x)\n", s32Ret);
        return s32Ret;
    }

    memcpy(&stVgsTask.stImgIn, pstFrmInfo, sizeof(VIDEO_FRAME_INFO_S));
    memcpy(&stVgsTask.stImgOut, pstFrmInfo, sizeof(VIDEO_FRAME_INFO_S));

    stVgsAddCover.enCoverType = COVER_QUAD_RANGLE;
    stVgsAddCover.u32Color = u32Color;
    stVgsAddCover.stQuadRangle.bSolid = HI_FALSE;
    stVgsAddCover.stQuadRangle.u32Thick = 2;

   
    memcpy(stVgsAddCover.stQuadRangle.stPoint, pstbbox->astPoint[0].astPoint_u, sizeof(pstbbox->astPoint[0].astPoint_u));
    s32Ret = HI_MPI_VGS_AddCoverTask(VgsHandle, &stVgsTask, &stVgsAddCover);
    if (s32Ret != HI_SUCCESS)
    {
        printf("HI_MPI_VGS_AddCoverTask fail,Error(%#x)\n", s32Ret);
        HI_MPI_VGS_CancelJob(VgsHandle);
        return s32Ret;
    }

  

    s32Ret = HI_MPI_VGS_EndJob(VgsHandle);
    if (s32Ret != HI_SUCCESS)
    {
        printf("HI_MPI_VGS_EndJob fail,Error(%#x)\n", s32Ret);
        HI_MPI_VGS_CancelJob(VgsHandle);
        return s32Ret;
    }

    return s32Ret;

}



void Yolov5_RECT_TO_DENRMALIZATION(MY_YOLO_RECT_ARRAY_S *pastRect_f, MY_YOLO_RECT_ARRAY_S *pastRect_u, HI_S32 img_W, HI_S32 img_H)
{
    // printf("##show_img_w->%d\n",img_W);
    // printf("##show_img_H->%d\n",img_H);

    int i,j;
    pastRect_u->u32TotalNum = pastRect_f->u32TotalNum;
    pastRect_u->u32ClsNum = pastRect_f->u32ClsNum;
    memcpy(pastRect_u->au32RoiNum,pastRect_f->au32RoiNum,sizeof(pastRect_f->au32RoiNum));
    if (pastRect_f->u32TotalNum == 0)
    {
        return;
    }
    for(i = 0; i < pastRect_f->u32ClsNum; i++)
    {
        for(j = 0; j < pastRect_f->au32RoiNum[i]; j++ )
        { 
            pastRect_u->astRect[i][j].f32Score = pastRect_f->astRect[i][j].f32Score;
            pastRect_u->astRect[i][j].stRect.stRect_u.uX = (int)(pastRect_f->astRect[i][j].stRect.stRect_f.fX * img_W) & (~1);
            pastRect_u->astRect[i][j].stRect.stRect_u.uY = (int)(pastRect_f->astRect[i][j].stRect.stRect_f.fY * img_H) & (~1);
            pastRect_u->astRect[i][j].stRect.stRect_u.uWidth = (int)(pastRect_f->astRect[i][j].stRect.stRect_f.fWidth * img_W) & (~1);
            pastRect_u->astRect[i][j].stRect.stRect_u.uHeight = (int)(pastRect_f->astRect[i][j].stRect.stRect_f.fHeight * img_H) & (~1);
            // printf("### X:%d   Y:%d    W:%d    H:%d\n",pastRect_u->astRect[i][j].stRect.stRect_u.uX,pastRect_u->astRect[i][j].stRect.stRect_u.uY,
            //pastRect_u->astRect[i][j].stRect.stRect_u.uWidth,pastRect_u->astRect[i][j].stRect.stRect_u.uHeight);
        }

    }  
    return;
}






HI_S32 SAMPLE_COMM_SVP_NNIE_Yolov5_FillRect(VIDEO_FRAME_INFO_S *pstFrmInfo, MY_YOLO_RECT_ARRAY_S* pstRect_u, HI_U32 u32Color)
{
    VGS_HANDLE VgsHandle = -1;
    HI_S32 s32Ret = HI_SUCCESS;
    HI_U32 i,j;
    VGS_TASK_ATTR_S stVgsTask;
    VGS_ADD_COVER_S stVgsAddCover;
    static HI_U32 u32Frm = 0;
    u32Frm++;
    if (0 == pstRect_u->u32TotalNum)
    {
        // printf("###Obj NUM->%d\n",pstRect_u->u32TotalNum);
        return s32Ret;
    }
    s32Ret = HI_MPI_VGS_BeginJob(&VgsHandle);
    if (s32Ret != HI_SUCCESS)
    {
        
        printf("Vgs begin job fail,Error(%#x)\n", s32Ret);
        return s32Ret;
    }

    memcpy(&stVgsTask.stImgIn, pstFrmInfo, sizeof(VIDEO_FRAME_INFO_S));
    memcpy(&stVgsTask.stImgOut, pstFrmInfo, sizeof(VIDEO_FRAME_INFO_S));

    stVgsAddCover.enCoverType = COVER_QUAD_RANGLE;
    stVgsAddCover.u32Color = u32Color;
    stVgsAddCover.stQuadRangle.bSolid = HI_FALSE;
    stVgsAddCover.stQuadRangle.u32Thick = 2;

    for (i = 0; i < pstRect_u->u32ClsNum; i++)
    {
        if(pstRect_u->au32RoiNum[i] == 0)
        {
            continue;
        }

        for (j = 0; j < pstRect_u->au32RoiNum[i]; j++)
        {
            MY_RECT_ARRAY_S astRect_u = {0};
            MY_POINT_ARRAY_S astPoint_u = {0};
            astRect_u.u16Num = 1;
            astRect_u.astRect[0].stRect_u = pstRect_u->astRect[i][j].stRect.stRect_u;
            RECT_TO_POINT(&astRect_u, &astPoint_u);
            memcpy(stVgsAddCover.stQuadRangle.stPoint, astPoint_u.astPoint[0].astPoint_u, sizeof(astPoint_u.astPoint[0].astPoint_u));
            s32Ret = HI_MPI_VGS_AddCoverTask(VgsHandle, &stVgsTask, &stVgsAddCover);
            if (s32Ret != HI_SUCCESS)
            {
                printf("HI_MPI_VGS_AddCoverTask fail,Error(%#x)\n", s32Ret);
                // SAMPLE_PRT("HI_MPI_VGS_AddCoverTask fail,Error(%#x)\n", s32Ret);
                HI_MPI_VGS_CancelJob(VgsHandle);
                return s32Ret;
            }

        }

    }

    s32Ret = HI_MPI_VGS_EndJob(VgsHandle);
    if (s32Ret != HI_SUCCESS)
    {
        printf("HI_MPI_VGS_EndJob fail,Error(%#x)\n", s32Ret);
        HI_MPI_VGS_CancelJob(VgsHandle);
        return s32Ret;
    }

    return s32Ret;

}



