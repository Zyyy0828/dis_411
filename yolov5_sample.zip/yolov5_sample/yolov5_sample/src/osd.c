#include "osd.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"
{
#endif
#endif /* End of #ifdef __cplusplus */

    static OsdSet *g_osds = NULL;
    static HI_S32 g_osd0 = -1;

    // 初始化osd参数：bindmod，grp，chn

    void init_osd(HI_OSD_BIND_MOD_E ebindMOD, HI_U32 Grp, HI_U32 Chn)
    {
        HI_S32 ret;
        HI_ASSERT(!g_osds);
        g_osds = OsdsCreate(ebindMOD, Grp, Chn);
        HI_ASSERT(g_osds);

        ret = OsdLibInit();
        HI_ASSERT(ret == HI_SUCCESS);

        g_osd0 = OsdsCreateRgn(g_osds);
        HI_ASSERT(g_osds >= 0);
    }

    static int fill_osdBuf(HI_CHAR *Cls, float Score, HI_CHAR *buf)
    {
        HI_S32 offset = 0;
        offset = snprintf_s(buf, NORM_BUF_SIZE, NORM_BUF_SIZE - 1, "%s: %u%%", Cls, (int)(Score * 100));
        if (offset > NORM_BUF_SIZE)
        {
            return -1;
        }
        return 0;
    }

    void draw_osd(HI_CHAR *Cls, int beginX, int beginY)
    {
        int ret = 0;
        static HI_CHAR prevOsd[NORM_BUF_SIZE] = "";
        static uint32_t prevBegX = 0;
        static uint32_t prevBegY = 0;
        HI_CHAR osdBuf[NORM_BUF_SIZE] = "";
        uint32_t begX = (uint32_t)beginX;
        uint32_t begY = (uint32_t)beginY;

        HI_S32 offset = snprintf_s(osdBuf, sizeof(osdBuf), sizeof(osdBuf) - 1, "%s", Cls);
        if (offset > sizeof(osdBuf))
        {
            return;
        }
      
        /*
         * 仅当计算结果与之前计算发生变化时，才重新打OSD输出文字
         * Only when the calculation result changes from the previous calculation, re-print the OSD output text
         */
        if ((strcmp(osdBuf, prevOsd) != 0))
        {
            // 复制字符
            HiStrxfrm(prevOsd, osdBuf, sizeof(prevOsd));
            HI_OSD_ATTR_S rgn;
            TxtRgnInit(&rgn, osdBuf, begX, begY, ARGB1555_YELLOW2); // font width and heigt use default 40
            // 在OsdSet中设置指定区域的属性
            OsdsSetRgn(g_osds, g_osd0, &rgn);
        }
    }
    
    /*void draw_osd(HI_CHAR *Cls, int beginX, int beginY)
    {
        int ret = 0;
        static HI_CHAR prevOsd[NORM_BUF_SIZE] = "";
        static uint32_t prevBegX = 0;
        static uint32_t prevBegY = 0;
        HI_CHAR osdBuf[NORM_BUF_SIZE] = "";
        uint32_t begX = (uint32_t)beginX;
        uint32_t begY = (uint32_t)beginY;

        HI_S32 offset = snprintf_s(osdBuf, sizeof(osdBuf), sizeof(osdBuf) - 1, "%u%%", Cls);
        if (offset > sizeof(osdBuf))
        {
            return;
        }
         
        /*
         * 仅当计算结果与之前计算发生变化时，才重新打OSD输出文字
         * Only when the calculation result changes from the previous calculation, re-print the OSD output text
         */
        /*if ((strcmp(osdBuf, prevOsd) != 0) || begX != prevBegX || begY != prevBegY)
        {
            // 复制字符
            HiStrxfrm(prevOsd, osdBuf, sizeof(prevOsd));
            HI_OSD_ATTR_S rgn;
            TxtRgnInit(&rgn, osdBuf, begX, begY, ARGB1555_YELLOW2); // 字体颜色font width and heigt use default 40
            // 在OsdSet中设置指定区域的属性
            OsdsSetRgn(g_osds, g_osd0, &rgn);
            // /*
            //  * 用户向VPSS发送数据
            //  * User sends data to VPSS
            //  */
            // ret = HI_MPI_VPSS_SendFrame(0, 0, srcFrm, 0);
            // if (ret != HI_SUCCESS) {
            //     SAMPLE_PRT("Error(%#x), HI_MPI_VPSS_SendFrame failed!\n", ret);
            // }
        //}
    //}

    void draw_detect_osd(HI_CHAR *Cls, float Score, int beginX, int beginY)
    {
        int ret = 0;
        static HI_CHAR prevOsd[NORM_BUF_SIZE] = "";
        static uint32_t prevBegX = 0;
        static uint32_t prevBegY = 0;
        HI_CHAR osdBuf[NORM_BUF_SIZE] = "";
        uint32_t begX = (uint32_t)beginX;
        uint32_t begY = (uint32_t)beginY;
        ret = fill_osdBuf(Cls, Score, osdBuf);
        /*
         * 仅当计算结果与之前计算发生变化时，才重新打OSD输出文字
         * Only when the calculation result changes from the previous calculation, re-print the OSD output text
         */
        // if ((strcmp(osdBuf, prevOsd) != 0) || begX != prevBegX || begY != prevBegY)
        if ((strcmp(osdBuf, prevOsd) != 0))
        {
            // 复制字符
            HiStrxfrm(prevOsd, osdBuf, sizeof(prevOsd));
            HI_OSD_ATTR_S rgn;
            TxtRgnInit(&rgn, osdBuf, begX, begY, ARGB1555_YELLOW2); // font width and heigt use default 40
            // 在OsdSet中设置指定区域的属性
            OsdsSetRgn(g_osds, g_osd0, &rgn);
        }
    }

    void destroy_osd(void)
    {
        OsdsClear(g_osds);
        OsdsDestroy(g_osds);
    }

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */