#ifndef __YOLOV5_H__
#define __YOLOV5_H__


#ifdef __cplusplus
extern "C" {
#endif


#include "my_svp_type.h"

#if 1
// static char* yolov5_class_names[] = {"cloth", "mask", "hat", "no mask", "no cloth", "no hat",};
// static char* yolov5_class_names[] = {"person", "hat", "reflective_clothes", "other_clothes",};
static char* yolov5_class_names[] = {"drink", "smoke", "phone"};
/*extern char* yolov5_class_names[] = {"person", "bicycle", "car", "motorbike", "aeroplane", "bus", "train", "truck", "boat",

                         "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep",

                         "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase",

                         "frisbee", "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket",

                         "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "donut", "apple", "sandwich",

                         "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "sofa", "pottedplant",

                         "bed", "diningtable", "toilet", "vmonitor", "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave",

                         "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"};*/

#endif


/*input model path*/
int my_yolov5_load_model(const char *model_path);

/*input frame (get nomalization points)*/
int my_yolov5_run(VIDEO_FRAME_INFO_S *pstExtFrmInfo,MY_YOLO_RECT_ARRAY_S *pstRect);


/*release yolov3*/
int my_yolov5_clear(void);




#ifdef __cplusplus
}
#endif

#endif