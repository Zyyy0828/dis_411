#ifndef __MY_SVP_TYPE__
#define __MY_SVP_TYPE__

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

#include "hi_common.h"
#include "hi_debug.h"
#include "hi_comm_video.h"
#include "hi_comm_vgs.h"
#include "hi_comm_ive.h"






#define MY_BBOX_NUM 64

/*===========Point For Bbox============*/
typedef struct my_FLOAT_POINT_S {
    HI_FLOAT fX;
    HI_FLOAT fY;
} MY_FLOAT_POINT_S;

typedef struct my_UINT_POINT_S {
    HI_S32 uX;
    HI_S32 uY;
} MY_UINT_POINT_S;


typedef union my_POINT_S
{
    MY_UINT_POINT_S astPoint_u[4];
    MY_FLOAT_POINT_S astPoint_f[4];
}MY_POINT_S;


typedef struct my_POINT_ARRAY_S
{
    HI_U16 u16Num;
    MY_POINT_S astPoint[MY_BBOX_NUM];
} MY_POINT_ARRAY_S;
/*=====================================*/

/*===========Rect For Bbox============*/
typedef struct my_FLOAT_RECT_S
{
    HI_FLOAT fX;
    HI_FLOAT fY;
    HI_FLOAT fWidth;
    HI_FLOAT fHeight;
}MY_FLOAT_RECT_S;

typedef struct my_UINT_RECT_S
{
    HI_S32 uX;
    HI_S32 uY;
    HI_S32 uWidth;
    HI_S32 uHeight;
}MY_UINT_RECT_S;

typedef union my_RECT_S
{
    MY_UINT_RECT_S stRect_u;
    MY_FLOAT_RECT_S stRect_f;
}MY_RECT_S;
 
typedef struct my_RECT_ARRAY_S
{
    HI_U16 u16Num;
    MY_RECT_S astRect[MY_BBOX_NUM];
} MY_RECT_ARRAY_S;
/*=====================================*/


/*KCF PRM*/
typedef enum trackState
{
    Get_Cor,
    InTrack,
    NoTrack
}TrackState;

typedef struct my_KCF_RES
{
    MY_FLOAT_RECT_S stResBbox;
    TrackState eTrackState;
}MY_KCF_RES;

/*定义更新框模式*/
enum FlashMode
{
    INIT_MODE = 0,
    MODIFY_MODE,
    UPDATE_MODE,
};
typedef enum FlashMode FLASHMODE;

typedef struct my_KCF_INPUT_PRM
{
    FLASHMODE eFlashmode;                  /*更新框模式*/

    MY_FLOAT_RECT_S stInputBboxInfo;      /*更新框的坐标 X、Y、W、H*/
   
    VIDEO_FRAME_INFO_S stKcfFrmInfo;      /*kcf img(1920*1080)*/
 
    MY_KCF_RES stKcfRes;            /*Result*/
}MY_KCF_INPUT_PRM;


/*SOT PRM*/
typedef struct my_SOT_INPUT_PRM
{
    HI_BOOL bFlashSelectBbox;              /*是否更新框*/
    MY_FLOAT_RECT_S stInputBboxInfo;      /*更新框的坐标 X、Y、W、H*/
   
    VIDEO_FRAME_INFO_S stKcfFrmInfo;      /*kcf img(1920*1080)*/
    VIDEO_FRAME_INFO_S stDetectFrmInfo;   /*nnie img(416*416)*/

    MY_FLOAT_RECT_S stResBbox;            /*Result*/
}MY_SOT_INPUT_PRM;




/*YOLOV3 PRM*/
#define MY_YOLOV3_MAX_CLASS_NUM 81
#define MY_YOLOV3_MAX_ROI_NUM_OF_CLASS 50


// typedef enum my_YOLO_CLASS
// {
//     Background,
//     Person,
//     Bicycle,
//     Car,
//     Motorbike,
//     Aeroplane,
//     Bus,
//     Train,
//     Truck,
//     Boat,
//     Traffic_Light
// }MY_YOLO_CLASS;


//v5
typedef enum my_YOLO_CLASS
{
    Person,
    Bicycle,
    Car,
    Motorbike,
    Aeroplane,
    Bus,
    Train,
    Truck,
    Boat,
    Other = 81,
    NoObject = 82
}MY_YOLO_CLASS;




/*print result, this sample has 81 classes:
        class 0:background      class 1:person       class 2:bicycle         class 3:car            class 4:motorbike      class 5:aeroplane
        class 6:bus             class 7:train        class 8:truck           class 9:boat           class 10:traffic light
        class 11:fire hydrant   class 12:stop sign   class 13:parking meter  class 14:bench         class 15:bird
        class 16:cat            class 17:dog         class 18:horse          class 19:sheep         class 20:cow
        class 21:elephant       class 22:bear        class 23:zebra          class 24:giraffe       class 25:backpack
        class 26:umbrella       class 27:handbag     class 28:tie            class 29:suitcase      class 30:frisbee
        class 31:skis           class 32:snowboard   class 33:sports ball    class 34:kite          class 35:baseball bat
        class 36:baseball glove class 37:skateboard  class 38:surfboard      class 39:tennis racket class 40bottle
        class 41:wine glass     class 42:cup         class 43:fork           class 44:knife         class 45:spoon
        class 46:bowl           class 47:banana      class 48:apple          class 49:sandwich      class 50orange
        class 51:broccoli       class 52:carrot      class 53:hot dog        class 54:pizza         class 55:donut
        class 56:cake           class 57:chair       class 58:sofa           class 59:pottedplant   class 60bed
        class 61:diningtable    class 62:toilet      class 63:vmonitor       class 64:laptop        class 65:mouse
        class 66:remote         class 67:keyboard    class 68:cell phone     class 69:microwave     class 70:oven
        class 71:toaster        class 72:sink        class 73:refrigerator   class 74:book          class 75:clock
        class 76:vase           class 77:scissors    class 78:teddy bear     class 79:hair drier    class 80:toothbrush*/
//  Traffic_Light,
//     Fire_Hydrant,
//     Stop_Sign,
//     Parking_Meter,
//     Bench, 
//     Bird,
//     Cat,
//     Dog,
//     Horse,
//     Sheep,
//     Cow,
//     Elephant,
//     Bear,
//     Zebra,
//     Giraffe,
//     Backpack,
//     Umbrella,
//     Handbag,
//     Tie,
//     Suitcase,
//     Frisbee,
//     Skis,
//     Snowboard,
//     Sports_Ball,
//     Kite,
//     Baseball_Bat,
//     Baseball_Glove,
//     SkateBoard,
//     SurfBoard,
//     Tennis_Racket,
//     Bottle,
//     Wine_Glass,
//     Cup,
//     Fork,
//     Knife,
//     Spoon,
//     Bowl,
//     Banana,
//     Apple,
//     Sandwich,
//     Orange,


// typedef struct my_RECT_S
// {
//     MY_FLOAT_POINT_S ast_fPoint[4]; /* The float point */  /*TODO: use union struct*/
//     MY_UINT_POINT_S ast_uPoint[4];  /* The uint point */
//     HI_FLOAT f32Score;
// } MY_RECT_S;





typedef struct my_YOLO_RECT_S
{
    MY_RECT_S stRect;
    HI_FLOAT f32Score;
} MY_YOLO_RECT_S;


typedef struct my_CLASS_RECT_S
{
    MY_FLOAT_RECT_S stRect;
    MY_YOLO_CLASS eClassIndex;
} MY_CLASS_RECT_S;


/*yolov3 Array rect info(normalization)*/
typedef struct my_YOLO_RECT_ARRAY_S
{
    HI_U32 u32ClsNum;                                                           /*model class num*/
    HI_U32 u32TotalNum;                                                         /*all roi num*/
    HI_U32 au32RoiNum[MY_YOLOV3_MAX_CLASS_NUM];                                 /*each class roi num*/
    MY_YOLO_RECT_S astRect[MY_YOLOV3_MAX_CLASS_NUM][MY_YOLOV3_MAX_ROI_NUM_OF_CLASS];
} MY_YOLO_RECT_ARRAY_S;









#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif /* __MY_SVP_TYPE_H__ */
