#ifndef __NNIE_CORE_H__
#define __NNIE_CORE_H__


#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <math.h>
#include <dirent.h>
#include <sys/time.h>


#include "hi_common.h"
#include "hi_comm_sys.h"
#include "hi_comm_svp.h"
#include "sample_comm.h"
#include "sample_comm_svp.h"
#include "sample_comm_nnie.h"
#include "sample_comm_ive.h"
#include "sample_svp_nnie_software.h"

#include "Tensor.h"
#include "my_svp_type.h"

#define SAMPLE_SVP_NNIE_PERF_STAT_OP_FORWARD_CLREAR()
#define SAMPLE_SVP_NNIE_PERF_STAT_OP_FORWARD_PRE_DST_FLUSH_TIME()
#define SAMPLE_SVP_NNIE_PERF_STAT_OP_FORWARD_OP_TIME()
#define SAMPLE_SVP_NNIE_PERF_STAT_OP_FORWARD_AFTER_DST_FLUSH_TIME()



/*Load model*/
int _nnie_load_model(const char *model_path, SAMPLE_SVP_NNIE_MODEL_S *s_stModel);

/*Init parameters*/
int nnie_param_init(SAMPLE_SVP_NNIE_MODEL_S *pstModel, SAMPLE_SVP_NNIE_CFG_S *pstCfg,SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam);

/*nnie inference*/
int nnie_inference(SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam, VIDEO_FRAME_INFO_S *pstExtFrmInfo, Tensor *arrFeature);

int nnie_inference_jpg(const unsigned char *data, SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam, Tensor *output_tensors);

/*DeInit parameters*/
int nnie_param_deinit(SAMPLE_SVP_NNIE_PARAM_S *pstNnieParam, SAMPLE_SVP_NNIE_MODEL_S *pstNnieModel);






#ifdef __cplusplus
}
#endif


#endif