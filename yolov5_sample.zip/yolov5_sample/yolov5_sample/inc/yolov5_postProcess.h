#ifndef _YOLOV5_POSTPROCESS_H_
#define _YOLOV5_POSTPROCESS_H_

#ifdef __cplusplus
extern "C" {
#endif  

#ifndef YOLO_MIN
#define YOLO_MIN(a,b)  ((a) > (b) ? (b) : (a))
#endif

#ifndef YOLO_MAX
#define YOLO_MAX(a,b)  ((a) < (b) ? (b) : (a))
#endif


typedef struct anchor_w_h
{
	float anchor_w;
	
	float anchor_h;
}anchor_w_h;


typedef struct yolov5_result
{
	float x;
	
	float y;

	float width;

	float height;

	int class_label;

	float confidence;

	struct yolov5_result* next;
}YOLOV5_RESULT;




static anchor_w_h  anchor_grids[3][3] = {{{10.0f, 13.0f}, {16.0f, 30.0f}, {33.0f, 23.0f}}, // small yolo layer 层 anchor

									{{30.0f, 61.0f}, {62.0f, 45.0f}, {59.0f, 119.0f}}, // middle yolo layer 层 anchor

									{{116.0f, 90.0f}, {156.0f, 198.0f}, {373.0f, 326.0f}}}; // large yolo layer 层 anchor
	
static float strides[3] = {8.0f, 16.0f, 32.0f}; // 每个 yolo 层，grid 大小，与上面顺序对应

// int map_size[3] = {40, 20, 10}; // 每个 yolo 层，feature map size 大小，与上面顺序对应



void yolov5_result_process(Tensor *arrFeature, float *strides, anchor_w_h (*anchor_grids)[3], \
							int imgW, int imgH, float prob_threshold, YOLOV5_RESULT **output_result);

void yolov5_result_sort(YOLOV5_RESULT *output_result);

void yolov5_nms(YOLOV5_RESULT *output_result, float iou_threshold);

void yolov5_printf_result(YOLOV5_RESULT *temp);

void yolov5_release_result(YOLOV5_RESULT *output_result);

#ifdef __cplusplus
}
#endif


#endif // FD_CONFIG
