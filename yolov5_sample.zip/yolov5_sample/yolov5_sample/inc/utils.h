#ifndef __MY_UTILS_H__
#define __MY_UTILS_H__

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */

#include "my_svp_type.h"



/*fill Rect to frame*/
HI_S32 MY_Fill_ONE_Rect(VIDEO_FRAME_INFO_S *pstFrmInfo, MY_POINT_ARRAY_S* pstbbox, HI_U32 u32Color);

void Yolov5_RECT_TO_DENRMALIZATION(MY_YOLO_RECT_ARRAY_S *pastRect_f, MY_YOLO_RECT_ARRAY_S *pastRect_u, HI_S32 img_W, HI_S32 img_H);

HI_S32 SAMPLE_COMM_SVP_NNIE_Yolov5_FillRect(VIDEO_FRAME_INFO_S *pstFrmInfo, MY_YOLO_RECT_ARRAY_S *pstRect, HI_U32 u32Color);





#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif /* __MY_UTILS_H__ */